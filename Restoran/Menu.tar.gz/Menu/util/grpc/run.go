package grpc

import (
	"errors"
	"net"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"syscall"

	util "git.bluebird.id/mini/util/microservice"
	"github.com/go-kit/kit/log"

	middle "github.com/grpc-ecosystem/go-grpc-middleware"
	recovery "github.com/grpc-ecosystem/go-grpc-middleware/recovery"
	"github.com/grpc-ecosystem/grpc-gateway/runtime"
	"golang.org/x/net/context"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials"
)

var (
	//ErrServer is internal server error
	ErrServer = errors.New("Internal server error")
)

//Recovery return grpc server option with recovery handler
func Recovery(logger log.Logger) []grpc.ServerOption {
	handler := func(p interface{}) (err error) {
		logger.Log("panic", p)
		return ErrServer
	}
	opts := []recovery.Option{
		recovery.WithRecoveryHandler(handler),
	}
	serverOptions := []grpc.ServerOption{
		middle.WithUnaryServerChain(
			recovery.UnaryServerInterceptor(opts...),
		),
		middle.WithStreamServerChain(
			recovery.StreamServerInterceptor(opts...),
		)}
	return serverOptions
}

func handleSignals(shutdown func(), stopping, exit chan bool) {
	c := make(chan os.Signal, 1)
	signal.Notify(c, syscall.SIGINT, syscall.SIGTERM, syscall.SIGQUIT, syscall.SIGHUP)
	<-c
	stopping <- true
	shutdown()
	exit <- true
}

//Serve listen for client request
func Serve(address string, server *grpc.Server, exit chan bool, logger log.Logger) {

	lis, err := net.Listen("tcp", address)
	if err != nil {
		logger.Log(util.LogError, err.Error())
		return
	}

	stopping := make(chan bool, 1)
	go handleSignals(func() { server.GracefulStop() }, stopping, exit)

	err = server.Serve(lis)
	if err != nil {
		return
	}

	select {
	case <-stopping:
		<-exit
	default:
		logger.Log(util.LogError, err.Error())
	}
}

//RegisterHTTPHandler register endpoint to http server
type RegisterHTTPHandler func(ctx context.Context, mux *runtime.ServeMux, endpoint string, opts []grpc.DialOption) error

//ServeHTTP listen for http request
func ServeHTTP(grpcAddress, httpAddress string, register RegisterHTTPHandler, creds credentials.TransportCredentials,
	exit chan bool, logger log.Logger, allowcors bool) {
	ctx := context.Background()
	ctx, cancel := context.WithCancel(ctx)
	defer cancel()

	mux := runtime.NewServeMux()
	var opts []grpc.DialOption
	if creds == nil {
		opts = []grpc.DialOption{grpc.WithInsecure()}
	} else {
		opts = []grpc.DialOption{grpc.WithTransportCredentials(creds)}
	}
	err := register(ctx, mux, grpcAddress, opts)
	if err != nil {
		return
	}

	stopping := make(chan bool, 1)
	go handleSignals(func() {}, stopping, exit)

	if allowcors {
		http.ListenAndServe(httpAddress, allowCORS(mux))
	} else {
		http.ListenAndServe(httpAddress, mux)
	}

	select {
	case <-stopping:
		<-exit
	default:
		logger.Log(util.LogError, err.Error())
	}
}

func allowCORS(h http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if origin := r.Header.Get("Origin"); origin != "" {
			w.Header().Set("Access-Control-Allow-Origin", origin)
			if r.Method == "OPTIONS" && r.Header.Get("Access-Control-Request-Method") != "" {
				headers := []string{"Content-Type", "Accept", "Authorization"}
				w.Header().Set("Access-Control-Allow-Headers", strings.Join(headers, ","))
				methods := []string{"GET", "HEAD", "POST", "PUT", "DELETE"}
				w.Header().Set("Access-Control-Allow-Methods", strings.Join(methods, ","))
				return
			}
		}
		h.ServeHTTP(w, r)
	})
}
