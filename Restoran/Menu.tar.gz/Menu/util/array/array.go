package array

//ContainsInt return true if array contains value, false otherwise
func ContainsInt(array []int, value int) bool {
	for _, val := range array {
		if val == value {
			return true
		}
	}
	return false
}

//ContainsInt32 return true if array contains value, false otherwise
func ContainsInt32(array []int32, value int32) bool {
	for _, val := range array {
		if val == value {
			return true
		}
	}
	return false
}

//ContainsString return true if array contains value, false otherwise
func ContainsString(array []string, value string) bool {
	for _, val := range array {
		if val == value {
			return true
		}
	}
	return false
}
