package metrics

import (
	"fmt"
	"time"

	metrics "github.com/rcrowley/go-metrics"
	influxdb "github.com/vrischmann/go-metrics-influxdb"
)

//Metrics capture gc and memory statistics
func Metrics(host, service string, interval time.Duration, url, schema, user, password string) {
	r := metrics.NewPrefixedRegistry(fmt.Sprintf("%s.%s.", host, service))
	metrics.RegisterDebugGCStats(r)
	metrics.RegisterRuntimeMemStats(r)

	go metrics.CaptureDebugGCStats(r, interval)
	go metrics.CaptureRuntimeMemStats(r, interval)

	go influxdb.InfluxDB(
		r,        // metrics registry
		interval, // interval
		url,      // the InfluxDB url
		schema,   // your InfluxDB database
		user,     // your InfluxDB user
		password, // your InfluxDB password
	)
}
