package microservice

import (
	"io"
	"os"
)

type logFileWriter struct {
	file string
}

func (lw *logFileWriter) Write(p []byte) (n int, err error) {
	f, err := os.OpenFile(lw.file, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return
	}
	defer f.Close()
	n, err = f.Write(p)
	return
}

//NewFileWriter returns new file writer
func NewFileWriter(file string) io.Writer {
	return &logFileWriter{file: file}
}
