package microservice

import (
	"os"
	"os/signal"
	"syscall"
	"time"

	tracer "git.bluebird.id/mini/tracer-go"
	"github.com/go-kit/kit/log"
	"github.com/go-kit/kit/sd/zk"
	"github.com/opentracing/opentracing-go"
)

const (
	servicePath  = "/service/"
	registryNode = "registry"
)

//Logger returns default logger
func Logger() log.Logger {
	logger := log.NewLogfmtLogger(os.Stderr)
	logger = log.With(logger, LogTime, log.DefaultTimestampUTC, LogCaller, log.DefaultCaller)

	return logger
}

//FileLogger returns file logger
func FileLogger(file string) log.Logger {
	logger := log.NewSyncLogger(log.NewLogfmtLogger(NewFileWriter(file)))
	logger = log.With(logger, LogTime, log.DefaultTimestampUTC, LogCaller, log.DefaultCaller)

	return logger
}

//Tracer returns default tracer
func Tracer(address string) opentracing.Tracer {
	return tracer.NewTracer(address)
}

//zkClient returns zk client
func zkClient(nodes []string, logger log.Logger) (zk.Client, error) {
	options := zk.ConnectTimeout(time.Second * 5)
	return zk.NewClient(nodes, logger, options)
}

//ServiceRegistry returns zk service registrar
func ServiceRegistry(nodes []string, serviceName, address string, logger log.Logger) (*zk.Registrar, error) {
	client, err := zkClient(nodes, logger)
	if err != nil {
		return nil, err
	}
	path := servicePath + serviceName
	service := zk.Service{Path: path, Name: registryNode, Data: []byte(address)}
	return zk.NewRegistrar(client, service, logger), nil
}

//ServiceDiscovery returns zk service instancer
func ServiceDiscovery(nodes []string, serviceName string, logger log.Logger) (*zk.Instancer, error) {
	client, err := zkClient(nodes, logger)
	if err != nil {
		return nil, err
	}
	path := servicePath + serviceName
	instancer, err := zk.NewInstancer(client, path, logger)
	if err != nil {
		return nil, err
	}
	return instancer, nil
}

//OnShutdown calls function on signal interrupt
func OnShutdown(shutdown func(), exit chan bool) {
	c := make(chan os.Signal, 1)
	signal.Notify(c, syscall.SIGINT, syscall.SIGTERM, syscall.SIGQUIT, syscall.SIGHUP)
	<-c
	shutdown()
	exit <- true
}
