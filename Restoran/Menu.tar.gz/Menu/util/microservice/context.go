package microservice

type contextKey string

func (c contextKey) String() string {
	return string(c)
}

var (
	//CtxACL is context key for acl
	CtxACL = contextKey("acl")
	//CtxUserID is context key for user id
	CtxUserID = contextKey("uid")
	//CtxDomain is context key for domain
	CtxDomain = contextKey("domain")
	//CtxPhone is context key for phone number
	CtxPhone = contextKey("phone_number")
	//CtxEmail is context key for email
	CtxEmail = contextKey("email")
	//CtxName is context key for user name
	CtxName = contextKey("name")
)
