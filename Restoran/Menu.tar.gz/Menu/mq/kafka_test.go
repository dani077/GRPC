package mq

import (
	"encoding/json"
	"log"
	"testing"
	"time"

	"github.com/Shopify/sarama"
)

type BinStr struct {
	Value int
}

func Marshal(b BinStr) ([]byte, error) {
	return json.Marshal(b)
}

func Unmarshal(data []byte) (BinStr, error) {
	var b BinStr
	err := json.Unmarshal(data, &b)
	return b, err
}

func TestConsumerGroup(t *testing.T) {
	consumer1 := NewConsumerGroup([]string{"127.0.0.1:9092", "127.0.0.1:9093"}, "myconsumer",
		sarama.OffsetNewest, nil, []string{"mytopic"})
	consumer2 := NewConsumerGroup([]string{"127.0.0.1:9092", "127.0.0.1:9093"}, "myconsumer",
		sarama.OffsetNewest, nil, []string{"mytopic"})

	start := make(chan bool)
	go func() {
		start <- true
		data, _ := consumer1.Consume()
		for msg := range data {
			result, _ := Unmarshal(msg.Value)
			log.Printf("consumer 1: %v", result.Value)
		}
	}()

	go func() {
		start <- true
		data, _ := consumer2.Consume()
		for msg := range data {
			result, _ := Unmarshal(msg.Value)
			log.Printf("consumer 2: %v", result.Value)
		}
	}()

	exit := make(chan bool)
	go func() {
		time.Sleep(5 * time.Second)
		<-start
		<-start
		producer := NewSyncProducer([]string{"127.0.0.1:9092", "127.0.0.1:9093"}, nil)
		for i := 0; i < 10; i++ {
			msg := BinStr{Value: i}
			data, _ := Marshal(msg)
			producer.Produce("mytopic", data)
			time.Sleep(time.Second)
		}
		time.Sleep(5 * time.Second)
		consumer1.Close()
		consumer2.Close()
		exit <- true
	}()

	<-exit
}

func TestSubscriber(t *testing.T) {
	handler1 := func(msg Message) error {
		result, _ := Unmarshal(msg.Value)
		log.Printf("consumer 1: %v", result.Value)
		return nil
	}

	handler2 := func(msg Message) error {
		result, _ := Unmarshal(msg.Value)
		log.Printf("consumer 2: %v", result.Value)
		return nil
	}

	consumer1 := NewSubscriberGroup([]string{"127.0.0.1:9092", "127.0.0.1:9093"}, "myconsumer",
		sarama.OffsetNewest, nil, []string{"mytopic"}, []MessageHandler{handler1})
	consumer2 := NewSubscriberGroup([]string{"127.0.0.1:9092", "127.0.0.1:9093"}, "myconsumer",
		sarama.OffsetNewest, nil, []string{"mytopic"}, []MessageHandler{handler2})

	start := make(chan bool)
	go func() {
		start <- true
		consumer1.Subscribe()
	}()

	go func() {
		start <- true
		consumer2.Subscribe()
	}()

	exit := make(chan bool)
	go func() {
		time.Sleep(10 * time.Second)
		<-start
		<-start
		producer := NewAsyncProducer([]string{"127.0.0.1:9092", "127.0.0.1:9093"}, nil)
		for i := 0; i < 10; i++ {
			msg := BinStr{Value: i}
			data, _ := Marshal(msg)
			producer.Produce("mytopic", data)
			time.Sleep(time.Second)
		}
		time.Sleep(5 * time.Second)
		consumer1.Close()
		consumer2.Close()
		exit <- true
	}()

	<-exit
}
