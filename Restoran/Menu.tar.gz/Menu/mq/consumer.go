package mq

import (
	cluster "github.com/bsm/sarama-cluster"
)

type consumerGroup struct {
	brokers  []string
	group    string
	offset   int64
	config   *cluster.Config
	topics   []string
	consumer *cluster.Consumer
	msgChan  chan Message
	errChan  chan error
}

//NewConsumerGroup returns new consumer group
func NewConsumerGroup(brokers []string, group string, offset int64,
	config *cluster.Config, topics []string) Consumer {
	if config == nil {
		return &consumerGroup{brokers: brokers, group: group, offset: offset,
			config: defaultConsumerGroupConfig(), topics: topics}
	}
	return &consumerGroup{brokers: brokers, group: group, offset: offset,
		config: config, topics: topics}
}

func defaultConsumerGroupConfig() *cluster.Config {
	config := cluster.NewConfig()
	config.Consumer.Return.Errors = true

	return config
}

func (c *consumerGroup) Consume() (<-chan Message, <-chan error) {
	var err error
	c.consumer, err = cluster.NewConsumer(c.brokers, c.group, c.topics, c.config)
	if err != nil {
		return nil, nil
	}

	c.msgChan = make(chan Message)
	c.errChan = make(chan error)

	go func() {
		for msg := range c.consumer.Messages() {
			c.msgChan <- Message{Topic: msg.Topic, Offset: msg.Offset, Value: msg.Value}
		}
	}()

	go func() {
		for errMsg := range c.consumer.Errors() {
			c.errChan <- errMsg
		}
	}()

	return c.msgChan, c.errChan
}

func (c *consumerGroup) Close() error {
	if c.errChan != nil {
		close(c.errChan)
	}
	if c.msgChan != nil {
		close(c.msgChan)
	}
	if c.consumer != nil {
		return c.consumer.Close()
	}

	return nil
}

type subscriberGroup struct {
	brokers  []string
	group    string
	offset   int64
	config   *cluster.Config
	topics   []string
	handlers []MessageHandler
	consumer *cluster.Consumer
}

//NewSubscriberGroup returns new subsriber group
func NewSubscriberGroup(brokers []string, group string, offset int64,
	config *cluster.Config, topics []string, handlers []MessageHandler) Subscriber {
	if config == nil {
		return &subscriberGroup{brokers: brokers, group: group, offset: offset,
			config: cluster.NewConfig(), topics: topics, handlers: handlers}
	}
	return &subscriberGroup{brokers: brokers, group: group, offset: offset, config: config,
		topics: topics, handlers: handlers}
}

func (c *subscriberGroup) Subscribe() {
	var err error
	c.consumer, err = cluster.NewConsumer(c.brokers, c.group, c.topics, c.config)
	if err != nil {
		return
	}

	go func() {
		for msg := range c.consumer.Messages() {
			message := Message{Topic: msg.Topic, Offset: msg.Offset, Value: msg.Value}
			for _, handler := range c.handlers {
				execute := handler
				go func() {
					execute(message)
				}()
			}
		}
	}()
}

func (c *subscriberGroup) Close() error {
	if c.consumer != nil {
		return c.consumer.Close()
	}

	return nil
}
