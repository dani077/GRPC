package mq

import "io"

//Message is queue message
type Message struct {
	Topic  string
	Offset int64
	Value  []byte
}

//MessageHandler is queue message handler
type MessageHandler func(Message) error

//Producer is message producer
type Producer interface {
	Produce(string, []byte) (int64, error)
}

//Consumer is message consumer
type Consumer interface {
	Consume() (<-chan Message, <-chan error)
	io.Closer
}

//Subscriber is message subscriber
type Subscriber interface {
	Subscribe()
	io.Closer
}
