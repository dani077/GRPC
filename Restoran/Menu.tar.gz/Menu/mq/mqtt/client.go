package mqtt

import (
	"context"

	paho "github.com/eclipse/paho.mqtt.golang"
	"github.com/go-kit/kit/endpoint"
)

//DecodeMessageFunc is function to decode message
type DecodeMessageFunc func(interface{}) (context.Context, interface{}, error)

//EncodeMessageFunc is function to encode message
type EncodeMessageFunc func(context.Context, interface{}) (interface{}, error)

//Handler is message payload handler
type Handler struct {
	Decode   DecodeMessageFunc
	Endpoint endpoint.Endpoint
}

//Subscriber is mqtt subscriber
type Subscriber interface {
	Subscribe() error
	Unsubscribe() error
}

//subscriber is mqtt subscriber implementation
type subscriber struct {
	brokers  []string
	qos      byte
	clientID string
	handlers map[string]Handler
	client   paho.Client
}

//NewSubscriber returns new subscriber
func NewSubscriber(brokers []string, qos byte, clientID string, handlers map[string]Handler) Subscriber {
	return &subscriber{brokers: brokers, qos: qos, clientID: clientID, handlers: handlers}
}

func (s *subscriber) Subscribe() error {
	opts := paho.NewClientOptions()
	for _, broker := range s.brokers {
		opts.AddBroker(broker)
	}
	opts.SetClientID(s.clientID)
	opts.SetCleanSession(false)

	s.client = paho.NewClient(opts)
	if token := s.client.Connect(); token.Wait() && token.Error() != nil {
		return token.Error()
	}

	for topic, handler := range s.handlers {
		msgHandler := func(cli paho.Client, msg paho.Message) {
			ctx, message, err := handler.Decode(msg)
			if err == nil {
				handler.Endpoint(ctx, message)
			}
		}

		if token := s.client.Subscribe(topic, s.qos, msgHandler); token.Wait() && token.Error() != nil {
			return token.Error()
		}
	}

	return nil
}

func (s *subscriber) Unsubscribe() error {
	for topic := range s.handlers {
		s.client.Unsubscribe(topic)
	}
	if s.client.IsConnected() {
		s.client.Disconnect(5000)
	}
	return nil
}

//Publisher is mqtt publisher
type Publisher interface {
	Publish(context.Context, string, interface{}) error
	Disconnect() error
}

//publisher is mqtt publisher implementation
type publisher struct {
	qos      byte
	retain   bool
	handlers map[string]EncodeMessageFunc
	client   paho.Client
}

//NewPublisher returns new publisher
func NewPublisher(brokers []string, qos byte, retain bool, clientID string, handlers map[string]EncodeMessageFunc) (Publisher, error) {
	opts := paho.NewClientOptions()
	for _, broker := range brokers {
		opts.AddBroker(broker)
	}
	opts.SetClientID(clientID)
	opts.SetCleanSession(false)

	client := paho.NewClient(opts)
	if token := client.Connect(); token.Wait() && token.Error() != nil {
		return nil, token.Error()
	}
	return &publisher{qos: qos, retain: retain, handlers: handlers, client: client}, nil
}

//Publish publishes message to broker
func (p *publisher) Publish(ctx context.Context, topic string, data interface{}) error {
	var msg interface{}
	var err error

	enc := p.handlers[topic]
	if enc == nil {
		msg = data
	} else {
		msg, err = enc(ctx, data)
		if err != nil {
			return err
		}
	}

	token := p.client.Publish(topic, p.qos, p.retain, msg)
	token.Wait()

	return token.Error()
}

func (p *publisher) Disconnect() error {
	p.client.Disconnect(5000)
	return nil
}
