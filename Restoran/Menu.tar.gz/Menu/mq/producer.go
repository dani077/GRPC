package mq

import (
	"sync"

	"github.com/Shopify/sarama"
)

type syncProducer struct {
	brokers []string
	config  *sarama.Config
}

//NewSyncProducer returns new sync producer
func NewSyncProducer(brokers []string, config *sarama.Config) Producer {
	if config == nil {
		return &syncProducer{brokers: brokers, config: defaultProducerConfig()}
	}
	return &syncProducer{brokers: brokers, config: config}
}

func defaultProducerConfig() *sarama.Config {
	config := sarama.NewConfig()
	config.Producer.RequiredAcks = sarama.WaitForAll // Wait for all in-sync replicas to ack the message
	config.Producer.Return.Successes = true
	config.Producer.Return.Errors = true
	config.Producer.Partitioner = sarama.NewRoundRobinPartitioner

	return config
}

func (sp *syncProducer) Produce(topic string, message []byte) (int64, error) {
	producer, err := sarama.NewSyncProducer(sp.brokers, sp.config)
	if err != nil {
		return -1, err
	}
	defer producer.Close()

	msg := sarama.ProducerMessage{Topic: topic, Value: sarama.ByteEncoder(message)}
	_, offset, err := producer.SendMessage(&msg)

	return offset, err
}

type asyncProducer struct {
	brokers []string
	config  *sarama.Config
}

//NewAsyncProducer returns new async producer
func NewAsyncProducer(brokers []string, config *sarama.Config) Producer {
	if config == nil {
		return &asyncProducer{brokers: brokers, config: defaultAsyncProducerConfig()}
	}
	return &asyncProducer{brokers: brokers, config: config}
}

func defaultAsyncProducerConfig() *sarama.Config {
	config := sarama.NewConfig()
	config.Producer.RequiredAcks = sarama.WaitForAll // Wait for all in-sync replicas to ack the message
	config.Producer.Return.Successes = true
	config.Producer.Return.Errors = true
	config.Producer.Partitioner = sarama.NewRoundRobinPartitioner

	return config
}

func (ap *asyncProducer) Produce(topic string, message []byte) (int64, error) {
	producer, err := sarama.NewAsyncProducer(ap.brokers, ap.config)
	if err != nil {
		return -1, err
	}
	defer closeProducer(producer)

	msg := sarama.ProducerMessage{Topic: topic, Value: sarama.ByteEncoder(message)}
	producer.Input() <- &msg

	return -1, err
}

func closeProducer(p sarama.AsyncProducer) {
	var wg sync.WaitGroup
	p.AsyncClose()

	wg.Add(2)
	go func() {
		for range p.Successes() {
		}
		wg.Done()
	}()
	go func() {
		for range p.Errors() {
		}
		wg.Done()
	}()
	wg.Wait()
}
