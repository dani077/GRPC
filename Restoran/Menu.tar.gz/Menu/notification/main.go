package main

import (
	"git.bluebird.id/bluebird/mq"
	svc "git.bluebird.id/bluebird/notification/server"
	"git.bluebird.id/bluebird/notification/storage"
	cfg "git.bluebird.id/bluebird/util/config"
	util "git.bluebird.id/bluebird/util/microservice"
)

func main() {

	logger := util.Logger()

	ok := cfg.AppConfig.LoadConfig()
	if !ok {
		logger.Log(util.LogError, "failed to load configuration")
		return
	}
	dbHost := cfg.Get(cfg.DBhost, "127.0.0.1:3306")
	dbName := cfg.Get(cfg.DBname, "notification")
	dbUser := cfg.Get(cfg.DBuid, "notification")
	dbPwd := cfg.Get(cfg.DBpwd, "notification")
	cachehost := cfg.Get("chhost", "127.0.0.1:6379")
	brokers := cfg.GetA("mqbrokers", "127.0.0.1:9092")

	publisher := mq.NewAsyncProducer(brokers, nil)
	templater := storage.NewTemplater(dbHost, dbName, dbUser, dbPwd, cachehost)
	service := svc.NewNotifier(templater, publisher)
	endpoints := svc.NewNotificationEndpoint(service)
	subscriber := svc.NewNotificationSubscriber(brokers, endpoints)

	subscriber.Subscribe()
	exit := make(chan bool, 1)
	util.OnShutdown(func() { subscriber.Close() }, exit)
	<-exit
}
