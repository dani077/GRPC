package server

import "context"

//NotificationType is notification media type
type NotificationType int

const (
	//EMAIL is notification via email
	EMAIL NotificationType = 0x1
	//SMS is notification via text message
	SMS NotificationType = 0x2
	//PUSH is notification via app push
	PUSH NotificationType = 0x4

	//TopicNotification is topic for notification
	TopicNotification = "notification"
	//TopicEmail is topic for email notification
	TopicEmail = "notification.email"
	//TopicSms is topic for sms notification
	TopicSms = "notification.sms"
	//TopicPush is topic for push notification
	TopicPush = "notification.push"

	//FieldRecipients is field for email recipients
	FieldRecipients = "recipients"
	//FieldCC is field for email cc
	FieldCC = "cc"
	//FieldBCC is field for email bcc
	FieldBCC = "bcc"
	//FieldSender is field for email/sms sender
	FieldSender = "sender"
	//FieldSubject is field for notification subject
	FieldSubject = "subject"
	//FieldMobile is field for mobile no
	FieldMobile = "mobile"
	//FieldDeviceID is field for device id
	FieldDeviceID = "deviceid"
)

//Notification is notification data structure
type Notification struct {
	ID        string
	MediaType NotificationType
	Data      map[string]string
}

//EmailNotification is email notification
type EmailNotification struct {
	Sender     string
	Recipients []string
	CC         []string
	BCC        []string
	Subject    string
	Attachment []byte
	Message    string
}

//SmsNotification is text message notification
type SmsNotification struct {
	Sender  string
	Mobile  string
	Message string
}

//PushNotification is app push notification
type PushNotification struct {
	DeviceID string
	Subject  string
	Message  string
}

//NotificationService is service to handle notification
type NotificationService interface {
	Notify(context.Context, Notification) error
}

func isEmail(media NotificationType) bool {
	return media&EMAIL == EMAIL
}

func isSms(media NotificationType) bool {
	return media&SMS == SMS
}

func isPush(media NotificationType) bool {
	return media&PUSH == PUSH
}
