package server

import (
	"bytes"
	"context"
	"encoding/gob"

	"git.bluebird.id/bluebird/mq"
	"github.com/Shopify/sarama"
)

func init() {
	gob.Register(Notification{})
}

//NewNotificationSubscriber return new notification subscriber
func NewNotificationSubscriber(brokers []string, endpoints NotificationEndpoint) mq.Subscriber {
	return mq.NewSubscriberGroup(brokers, TopicNotification, sarama.OffsetNewest, nil,
		[]string{TopicNotification}, []mq.MessageHandler{notificationHandler(endpoints)})
}

func notificationHandler(endpoint NotificationEndpoint) mq.MessageHandler {
	return func(message mq.Message) error {
		buf := bytes.NewBuffer(message.Value)
		var notification Notification
		err := gob.NewDecoder(buf).Decode(&notification)
		if err != nil {
			return err
		}

		_, err = endpoint.notificationEndpoint(context.Background(), notification)
		return err
	}
}
