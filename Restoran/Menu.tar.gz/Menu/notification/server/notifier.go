package server

import (
	"bytes"
	"context"
	"encoding/gob"
	html "html/template"
	"strings"
	text "text/template"

	"git.bluebird.id/bluebird/mq"
	"git.bluebird.id/bluebird/notification/storage"
)

type notifier struct {
	templater storage.Templater
	publisher mq.Producer
}

func init() {
	gob.Register(EmailNotification{})
	gob.Register(SmsNotification{})
	gob.Register(PushNotification{})
}

//NewNotifier returns new notification service
func NewNotifier(templater storage.Templater, producer mq.Producer) NotificationService {
	return &notifier{templater: templater, publisher: producer}
}

func (n *notifier) Notify(ctx context.Context, notification Notification) error {
	var err error

	if isEmail(notification.MediaType) {
		template, terr := n.templater.GetTemplate(notification.ID, int(EMAIL))
		if terr != nil {
			err = terr
		} else {
			tmpl, eerr := html.New(notification.ID).Parse(template.Message)
			if eerr != nil {
				err = eerr
			} else {
				var tmplbuf bytes.Buffer
				tmpl.Execute(&tmplbuf, notification.Data)
				msg := tmplbuf.String()

				email := EmailNotification{Recipients: strings.Split(notification.Data[FieldRecipients], ","),
					Sender: notification.Data[FieldSender], Subject: notification.Data[FieldSubject]}
				if len(email.Sender) == 0 {
					email.Sender = template.Sender
				}
				if len(email.Subject) == 0 {
					email.Subject = template.Subject
				}
				email.Message = msg

				var msgbuf bytes.Buffer
				gob.NewEncoder(&msgbuf).Encode(email)

				n.publisher.Produce(TopicEmail, msgbuf.Bytes())
			}
		}
	}

	if isSms(notification.MediaType) {
		template, terr := n.templater.GetTemplate(notification.ID, int(SMS))
		if terr != nil {
			err = terr
		} else {
			tmpl, eerr := text.New(notification.ID).Parse(template.Message)
			if eerr != nil {
				err = eerr
			} else {
				var tmplbuf bytes.Buffer
				tmpl.Execute(&tmplbuf, notification.Data)
				msg := tmplbuf.String()

				sms := SmsNotification{Mobile: notification.Data[FieldMobile],
					Sender: notification.Data[FieldSender]}
				if len(sms.Sender) == 0 {
					sms.Sender = template.Sender
				}
				sms.Message = msg

				var msgbuf bytes.Buffer
				gob.NewEncoder(&msgbuf).Encode(sms)

				n.publisher.Produce(TopicSms, msgbuf.Bytes())
			}
		}
	}
	if isPush(notification.MediaType) {
		template, terr := n.templater.GetTemplate(notification.ID, int(PUSH))
		if terr != nil {
			err = terr
		} else {
			tmpl, eerr := text.New(notification.ID).Parse(template.Message)
			if eerr != nil {
				err = eerr
			} else {
				var tmplbuf bytes.Buffer
				tmpl.Execute(&tmplbuf, notification.Data)
				msg := tmplbuf.String()

				push := PushNotification{DeviceID: notification.Data[FieldDeviceID],
					Subject: notification.Data[FieldSubject]}
				if len(push.Subject) == 0 {
					push.Subject = template.Subject
				}
				push.Message = msg

				var msgbuf bytes.Buffer
				gob.NewEncoder(&msgbuf).Encode(push)

				n.publisher.Produce(TopicPush, msgbuf.Bytes())
			}
		}
	}

	return err
}
