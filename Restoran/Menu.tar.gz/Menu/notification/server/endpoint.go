package server

import (
	"context"

	"github.com/go-kit/kit/endpoint"
)

//NotificationEndpoint is notification endpoint
type NotificationEndpoint struct {
	notificationEndpoint endpoint.Endpoint
}

//NewNotificationEndpoint returns new notification endpoint
func NewNotificationEndpoint(service NotificationService) NotificationEndpoint {
	notifEp := makeNotificationEndpoint(service)
	return NotificationEndpoint{notificationEndpoint: notifEp}
}

func makeNotificationEndpoint(service NotificationService) endpoint.Endpoint {
	return func(ctx context.Context, request interface{}) (response interface{}, err error) {
		req := request.(Notification)
		err = service.Notify(ctx, req)
		return nil, err
	}
}
