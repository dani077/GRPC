package storage

import (
	"bytes"
	"database/sql"
	"errors"
	"fmt"

	"github.com/go-redis/redis"
	_ "github.com/go-sql-driver/mysql" //mysql driver
)

const (
	fieldSender        = "sender"
	fieldSubject       = "subject"
	fieldMessage       = "message"
	selectTemplate     = "select template_id, media_type, sender, subject, message from template"
	selectTemplateByID = "select sender, subject, message from template where template_id = ? and media_type = ?"
)

var (
	//ErrTemplateNotFound is error for template not found
	ErrTemplateNotFound = errors.New("Template not found")
)

//Template specifies notification template
type Template struct {
	Sender  string
	Subject string
	Message string
}

//Templater is templating service
type Templater interface {
	LoadTemplate()
	GetTemplate(string, int) (Template, error)
}

type dbCacheTemplater struct {
	db    *sql.DB
	cache *redis.Client
}

func dataSourceName(url, schema, user, password string) string {
	var buffer bytes.Buffer
	buffer.WriteString(user)
	buffer.WriteString(":")
	buffer.WriteString(password)
	buffer.WriteString("@tcp(")
	buffer.WriteString(url)
	buffer.WriteString(")/")
	buffer.WriteString(schema)
	return buffer.String()
}

//NewTemplater returns new templater
func NewTemplater(dbURL, schema, user, password, cacheURL string) Templater {
	db, err := sql.Open("mysql", dataSourceName(dbURL, schema, user, password))
	if err != nil {
		panic(err)
	}
	return &dbCacheTemplater{db: db, cache: redis.NewClient(&redis.Options{Addr: cacheURL})}
}

func (t *dbCacheTemplater) LoadTemplate() {
	rows, err := t.db.Query(selectTemplate)
	if err != nil {
		return
	}
	defer rows.Close()

	pipe := t.cache.Pipeline()
	for rows.Next() {
		var id, media, sender, subject, message string
		err := rows.Scan(&id, &media, &sender, &subject, &message)
		if err != nil {
			continue
		}
		id = fmt.Sprintf("%s.%s", id, media)
		fields := make(map[string]interface{})
		fields[fieldSender] = sender
		fields[fieldSubject] = subject
		fields[fieldMessage] = message
		pipe.HMSet(id, fields)
	}
	pipe.Exec()
}

func (t *dbCacheTemplater) GetTemplate(id string, media int) (Template, error) {
	key := fmt.Sprintf("%s.%d", id, media)
	templateMap := t.cache.HGetAll(key).Val()
	template := Template{}
	if len(templateMap) == 0 {
		err := t.db.QueryRow(selectTemplateByID, id, media).Scan(&template.Sender, &template.Subject, &template.Message)
		if err == nil {
			fields := make(map[string]interface{})
			fields[fieldSender] = template.Sender
			fields[fieldSubject] = template.Subject
			fields[fieldMessage] = template.Message
			t.cache.HMSet(key, fields)
		} else {
			return template, err
		}
	} else {
		template.Sender = templateMap[fieldSender]
		template.Subject = templateMap[fieldSubject]
		template.Message = templateMap[fieldMessage]
	}

	return template, nil
}
