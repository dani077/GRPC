package tracer

import (
	"fmt"

	bbtc "git.bluebird.id/mini/tracer-go/bbtracer"
	pb "git.bluebird.id/mini/tracer-go/grpc"
)

func TypeOf(v interface{}) string {
	switch t := v.(type) {
	case string:
		return "string"
	case bool:
		return "bool"
	case int64:
		return "int64"
	case int:
		return "int"
	case float64:
		return "float64"
	default:
		_ = t
		return "unknown"
	}
}

func StringValueOf(value *pb.KeyValue) string {
	switch value.Value.(type) {
	case *pb.KeyValue_StringValue:
		return fmt.Sprintf("%s", value.GetStringValue())
	case *pb.KeyValue_BoolValue:
		return fmt.Sprintf("%t", value.GetBoolValue())
	case *pb.KeyValue_IntValue:
		return fmt.Sprintf("%d", value.GetIntValue())
	case *pb.KeyValue_Int64Value:
		return fmt.Sprintf("%d", value.GetInt64Value())
	case *pb.KeyValue_Float64Value:
		return fmt.Sprintf("%d", value.GetFloat64Value())
	case *pb.KeyValue_BinaryValue:
		return fmt.Sprintf("%v", value.GetBinaryValue())
	default:
		return "NIL"
	}
}

func toKeyValue(k string, v interface{}) *pb.KeyValue {
	switch t := v.(type) {
	case string:
		return &pb.KeyValue{
			k, 1,
			&pb.KeyValue_StringValue{v.(string)},
		}
	case bool:
		return &pb.KeyValue{
			k, 2,
			&pb.KeyValue_BoolValue{v.(bool)},
		}
	case int64:
		return &pb.KeyValue{
			k, 3,
			&pb.KeyValue_Int64Value{v.(int64)},
		}
	case int:
		return &pb.KeyValue{
			k, 4,
			&pb.KeyValue_IntValue{v.(int32)},
		}
	case float64:
		return &pb.KeyValue{
			k, 5,
			&pb.KeyValue_Float64Value{v.(float64)},
		}
	default:
		_ = t
		return &pb.KeyValue{Key: k}
	}
}

func toGrpcSpan(span bbtc.RawSpan) pb.Span {
	spanCtx := span.Context

	traceId := int64(spanCtx.TraceID)
	spanId := int64(spanCtx.SpanID)
	parentId := int64(span.ParentSpanID)

	startTime := span.Start.Unix()
	finishTime := span.Start.Add(span.Duration).Unix()

	//for k, v := range spanCtx.Baggage {
	//}

	eTags := []*pb.KeyValue{}
	for k, v := range span.Tags {
		kv := toKeyValue(k, v)
		eTags = append(eTags, kv)
	}

	eLogs := []*pb.Log{}
	for _, v := range span.Logs {
		eLog := pb.Log{Timestamp: v.Timestamp.Unix()}
		for _, l := range v.Fields {
			toKeyValue(l.Key(), l.Value())
			eLog.Fields = append(eLog.Fields, toKeyValue(l.Key(), l.Value()))
		}
		eLogs = append(eLogs, &eLog)
	}

	eRefs := []*pb.SpanRef{}
	for _, v := range span.Refs {
		eRef := &v
		eRefs = append(eRefs, eRef)
	}

	return pb.Span{
		traceId,
		spanId,
		parentId,
		"",
		"",
		span.Operation,
		startTime,
		finishTime,
		0,
		eTags,
		eLogs,
		eRefs,
	}
}
