package tracer

import (
	"context"
	"log"

	bbtc "git.bluebird.id/mini/tracer-go/bbtracer"
	pb "git.bluebird.id/mini/tracer-go/grpc"
	"google.golang.org/grpc"
)

type spanRecorder struct {
	Address string
}

func newSpanRecorder(address string) *spanRecorder {
	return &spanRecorder{Address: address}
}

func (recorder *spanRecorder) RecordSpan(span bbtc.RawSpan) {
	eSpan := toGrpcSpan(span)
	conn, err := grpc.Dial(recorder.Address, grpc.WithInsecure())

	if err != nil {
		log.Printf("cannot connect:	%v", err)
	}
	defer conn.Close()

	c := pb.NewTracerClient(conn)
	r, err := c.Send(context.Background(), &pb.TracerRequest{&eSpan})

	if err != nil {
		log.Printf("Could not send tracing: %v", err)
	}
	log.Printf("Response: %v", r)
}
