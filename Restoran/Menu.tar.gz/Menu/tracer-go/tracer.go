package tracer

import (
	bbtc "git.bluebird.id/mini/tracer-go/bbtracer"
	otc "github.com/opentracing/opentracing-go"
)

// ServiceID tracer server discovery ID
const ServiceID string = "tracer.bluebird.id"

// NewTracer create new tracer connected to specific server
func NewTracer(address string) otc.Tracer {
	return bbtc.New(newSpanRecorder(address))
}

// NewLoggerTracer create logger tracer
func NewLoggerTracer() otc.Tracer {
	return bbtc.New(NewLoggerSpanRecorder())
}

// NewNullTracer create NULL or NOOP tracer
func NewNullTracer() otc.Tracer {
	return otc.NoopTracer{}
}
