package tracer

import (
	"encoding/json"
	"log"

	bbtc "git.bluebird.id/mini/tracer-go/bbtracer"
)

type LoggerSpanRecorder struct {
}

func NewLoggerSpanRecorder() *LoggerSpanRecorder {
	return new(LoggerSpanRecorder)
}

func (*LoggerSpanRecorder) RecordSpan(span bbtc.RawSpan) {
	js, _ := json.Marshal(span)
	log.Printf("Span: %s", string(js))

	eSpan := toGrpcSpan(span)
	eJs, err := json.Marshal(eSpan)
	if err != nil {
		log.Printf("Error: %v", err)
		return
	}
	log.Printf("Span: %s", string(eJs))
}
