#!/usr/bin/env bash

CWD=$(cd . && pwd)
PRG=$0
BASEDIR=$(cd "$(dirname $PRG)" && pwd)
BASENAME=$(basename "$PRG")
while [ -L "$BASEDIR/$BASENAME" ]; do
    PRG=$(readlink "$BASEDIR/$BASENAME")
    BASEDIR=$(cd "$BASEDIR" && cd "$(dirname $PRG)" && pwd)
    BASENAME=$(basename "$PRG")
done

cd "$BASEDIR" && protoc -I../tracer-proto --go_out=plugins=grpc:grpc ../tracer-proto/*.proto
