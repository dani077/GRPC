package client

import (
	"context"
	"time"

	trc "git.bluebird.id/bluebird/tracer-go"
	pb "git.bluebird.id/bluebird/tracer-go/grpc"
	svc "git.bluebird.id/bluebird/tracer-go/server"
	util "git.bluebird.id/bluebird/util/grpc"
	disc "git.bluebird.id/bluebird/util/microservice"
	"github.com/go-kit/kit/circuitbreaker"
	"github.com/go-kit/kit/endpoint"
	"github.com/go-kit/kit/log"
	"github.com/go-kit/kit/sd"
	"github.com/go-kit/kit/sd/lb"
	"github.com/go-kit/kit/tracing/opentracing"
	grpctransport "github.com/go-kit/kit/transport/grpc"
	stdopentracing "github.com/opentracing/opentracing-go"
	"github.com/sony/gobreaker"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials"
)

const grpcServiceName string = "grpc.Tracer"

//NewGRPCClient returns new secret grpc client
func NewGRPCClient(nodes []string, creds credentials.TransportCredentials,
	logger log.Logger) (svc.TracerService, error) {
	instancer, err := disc.ServiceDiscovery(nodes, trc.ServiceID, logger)
	if err != nil {
		return nil, err
	}

	retryMax := 3
	retryTimeout := 500 * time.Millisecond

	var keyEp endpoint.Endpoint
	{
		factory := util.EndpointFactory(makeSendEndpoint, creds, retryTimeout, trc.NewNullTracer(), logger)
		endpointer := sd.NewEndpointer(instancer, factory, logger)
		balancer := lb.NewRoundRobin(endpointer)
		retry := lb.Retry(retryMax, retryTimeout, balancer)
		keyEp = retry
	}

	return svc.TracerEndpoint{SendTracerEndpoint: keyEp}, nil
}

func makeSendEndpoint(conn *grpc.ClientConn, timeout time.Duration, tracer stdopentracing.Tracer, logger log.Logger) endpoint.Endpoint {
	endpoint := grpctransport.NewClient(
		conn,
		grpcServiceName,
		"Send",
		encodeTracerRequest,
		decodeTracerResponse,
		pb.TracerResponse{},
		grpctransport.ClientBefore(opentracing.ContextToGRPC(tracer, logger)),
	).Endpoint()
	// endpoint = opentracing.TraceClient(tracer, "Send")(endpoint)
	endpoint = circuitbreaker.Gobreaker(gobreaker.NewCircuitBreaker(gobreaker.Settings{
		Name:    "Send",
		Timeout: timeout,
		//Timeout: 30 * time.Second,
	}))(endpoint)

	return endpoint
}

func encodeTracerRequest(_ context.Context, request interface{}) (interface{}, error) {
	req := request.(pb.TracerRequest)
	return &pb.TracerRequest{Span: req.Span}, nil
}

func decodeTracerResponse(_ context.Context, response interface{}) (interface{}, error) {
	resp := response.(*pb.TracerResponse)
	return pb.TracerResponse{Status: resp.Status, Origin: resp.Origin, Text: resp.Text}, nil
}
