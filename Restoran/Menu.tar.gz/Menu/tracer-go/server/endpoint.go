package server

import (
	"context"

	pb "git.bluebird.id/bluebird/tracer-go/grpc"
	"github.com/go-kit/kit/endpoint"
)

//TracerEndpoint is tracer service endpoint
type TracerEndpoint struct {
	SendTracerEndpoint endpoint.Endpoint
}

//NewTracerEndpoint return new key endpoint
func NewTracerEndpoint(service TracerService) TracerEndpoint {
	var tracerEp endpoint.Endpoint
	{
		tracerEp = makeSendTracerEndpoint(service)
	}
	return TracerEndpoint{SendTracerEndpoint: tracerEp}
}

func makeSendTracerEndpoint(service TracerService) endpoint.Endpoint {
	return func(ctx context.Context, request interface{}) (interface{}, error) {
		req := request.(pb.TracerRequest)
		resp, err := service.Send(ctx, req)
		return resp, err
	}
}

//Send send tracing endpoint
func (ep TracerEndpoint) Send(ctx context.Context, in pb.TracerRequest) (pb.TracerResponse, error) {
	resp, err := ep.SendTracerEndpoint(ctx, in)
	if err != nil {
		return pb.TracerResponse{Origin: pb.ResponseOrigin_NONE, Status: -1}, err
	}
	response := resp.(pb.TracerResponse)
	return response, nil
}
