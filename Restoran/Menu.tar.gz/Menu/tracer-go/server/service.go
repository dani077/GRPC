package server

import (
	"context"

	pb "git.bluebird.id/bluebird/tracer-go/grpc"
)

// TracerService Tracer service bridge
type TracerService interface {
	Send(ctx context.Context, in pb.TracerRequest) (pb.TracerResponse, error)
}
