package bbtracer

import (
	"time"

	pb "git.bluebird.id/mini/tracer-go/grpc"
	btc "github.com/opentracing/basictracer-go"
	otc "github.com/opentracing/opentracing-go"
)

// Tracer extends the opentracing.Tracer interface with methods to
// probe implementation state, for use by basictracer consumers.
type Tracer interface {
	otc.Tracer

	// Options gets the Options used in New() or NewWithOptions().
	Options() Options
}

// Options allows creating a customized Tracer via NewWithOptions. The object
// must not be updated when there is an active tracer using it.
type Options struct {
	btc.Options

	Recorder             SpanRecorder
	NewSpanEventListener func() func(SpanEvent)
}

// DefaultOptions returns an Options object with a 1 in 64 sampling rate and
// all options disabled. A Recorder needs to be set manually before using the
// returned object with a Tracer.
func DefaultOptions() Options {
	return Options{
		Options: btc.Options{
			ShouldSample:   func(traceID uint64) bool { return traceID%64 == 0 },
			MaxLogsPerSpan: 100,
		}}
}

// NewWithOptions creates a customized Tracer.
func NewWithOptions(opts Options) otc.Tracer {
	rval := &tracerImpl{options: opts}
	rval.textPropagator = &textMapPropagator{rval}
	rval.binaryPropagator = &binaryPropagator{rval}
	rval.accessorPropagator = &accessorPropagator{rval}
	return rval
}

// New creates and returns a standard Tracer which defers completed Spans to
// `recorder`.
// Spans created by this Tracer support the ext.SamplingPriority tag: Setting
// ext.SamplingPriority causes the Span to be Sampled from that point on.
func New(recorder SpanRecorder) otc.Tracer {
	opts := DefaultOptions()
	opts.Recorder = recorder
	return NewWithOptions(opts)
}

// Implements the `Tracer` interface.
type tracerImpl struct {
	options            Options
	textPropagator     *textMapPropagator
	binaryPropagator   *binaryPropagator
	accessorPropagator *accessorPropagator
}

func (t *tracerImpl) StartSpan(operationName string,
	opts ...otc.StartSpanOption) otc.Span {

	sso := otc.StartSpanOptions{}
	for _, o := range opts {
		o.Apply(&sso)
	}
	return t.StartSpanWithOptions(operationName, sso)
}

func (t *tracerImpl) getSpan() *spanImpl {
	if t.options.EnableSpanPool {
		sp := spanPool.Get().(*spanImpl)
		sp.reset()
		return sp
	}
	return &spanImpl{}
}

func (t *tracerImpl) StartSpanWithOptions(operationName string,
	opts otc.StartSpanOptions) otc.Span {

	// Start time.
	startTime := opts.StartTime
	if startTime.IsZero() {
		startTime = time.Now()
	}

	// Tags.
	tags := opts.Tags

	// Build the new span. This is the only allocation: We'll return this as
	// an opentracing.Span.
	sp := t.getSpan()

	var refs []pb.SpanRef
	sp.raw.Context.SpanID = randomID()

	// Look for a parent in the list of References.
	for _, ref := range opts.References {
		refCtx := ref.ReferencedContext.(SpanContext)
		sp.raw.Context.TraceID = refCtx.TraceID

		switch ref.Type {
		case otc.ChildOfRef:
			refCtx := ref.ReferencedContext.(SpanContext)
			sp.raw.Context.Sampled = refCtx.Sampled
			sp.raw.ParentSpanID = refCtx.SpanID

			if l := len(refCtx.Baggage); l > 0 {
				sp.raw.Context.Baggage = make(map[string]string, l)
				for k, v := range refCtx.Baggage {
					sp.raw.Context.Baggage[k] = v
				}
			}

			// no parent span found
			if sp.raw.Context.TraceID != 0 {
				ref := pb.SpanRef{
					RefType: pb.ReferenceType_ChildOf,
					SpanId:  int64(sp.raw.Context.SpanID),
					TraceId: int64(sp.raw.Context.TraceID),
				}
				refs = append(refs, ref)
			}
		case otc.FollowsFromRef:
			// no prevoius span found
			if sp.raw.Context.TraceID != 0 {
				ref := pb.SpanRef{
					RefType: pb.ReferenceType_FollowFrom,
					SpanId:  int64(sp.raw.Context.SpanID),
					TraceId: int64(sp.raw.Context.TraceID),
				}
				refs = append(refs, ref)
			}
		}
	}

	if sp.raw.Context.TraceID == 0 {
		// No parent Span found; allocate new trace and span ids and determine
		// the Sampled status.
		sp.raw.Context.TraceID, sp.raw.Context.SpanID = randomID2()
		sp.raw.Context.Sampled = t.options.ShouldSample(sp.raw.Context.TraceID)
	}

	return t.startSpanInternal(sp, operationName, startTime, tags)
}

func (t *tracerImpl) startSpanInternal(sp *spanImpl, operationName string,
	startTime time.Time, tags otc.Tags) otc.Span {

	sp.tracer = t
	if t.options.NewSpanEventListener != nil {
		sp.event = t.options.NewSpanEventListener()
	}
	sp.raw.Operation = operationName
	sp.raw.Start = startTime
	sp.raw.Duration = -1
	sp.raw.Tags = tags
	if t.options.DebugAssertSingleGoroutine {
		sp.SetTag(debugGoroutineIDTag, curGoroutineID())
	}
	defer sp.onCreate(operationName)
	return sp
}

type delegatorType struct{}

// Delegator is the format to use for DelegatingCarrier.
var Delegator delegatorType

func (t *tracerImpl) Inject(sc otc.SpanContext, format interface{},
	carrier interface{}) error {

	switch format {
	case otc.TextMap, otc.HTTPHeaders:
		return t.textPropagator.Inject(sc, carrier)
	case otc.Binary:
		return t.binaryPropagator.Inject(sc, carrier)
	}
	if _, ok := format.(delegatorType); ok {
		return t.accessorPropagator.Inject(sc, carrier)
	}
	return otc.ErrUnsupportedFormat
}

func (t *tracerImpl) Extract(format interface{},
	carrier interface{}) (otc.SpanContext, error) {

	switch format {
	case otc.TextMap, otc.HTTPHeaders:
		return t.textPropagator.Extract(carrier)
	case otc.Binary:
		return t.binaryPropagator.Extract(carrier)
	}
	if _, ok := format.(delegatorType); ok {
		return t.accessorPropagator.Extract(carrier)
	}
	return nil, otc.ErrUnsupportedFormat
}

func (t *tracerImpl) Options() Options {
	return t.options
}
