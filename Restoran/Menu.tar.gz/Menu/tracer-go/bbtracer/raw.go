package bbtracer

import (
	pb "git.bluebird.id/mini/tracer-go/grpc"
	btc "github.com/opentracing/basictracer-go"
)

// RawSpan encapsulates all state associated with a (finished) Span.
type RawSpan struct {
	btc.RawSpan

	Context SpanContext
	Refs    []pb.SpanRef
}
